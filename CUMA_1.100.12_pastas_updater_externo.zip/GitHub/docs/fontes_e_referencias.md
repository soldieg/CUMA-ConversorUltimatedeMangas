# Fontes e referências do CUMA


Esta seção lista as fontes de código, bibliotecas, repositórios, serviços e especificações técnicas identificados no projeto. Não se trata de fontes tipográficas.

### Código-fonte e distribuição do CUMA

- **Repositório do CUMA:** `https://github.com/soldieg/CUMA`
- **GitHub Releases do CUMA:** `https://github.com/soldieg/CUMA/releases`
- **Manifesto de atualização estável:** `https://raw.githubusercontent.com/soldieg/CUMA/main/updates/stable.json`
- **Arquivo de atualização distribuído:** `https://github.com/soldieg/CUMA/releases/download/Stable/CUMA_windows.zip`

### Referência XTCH/XTH/XTEINK

- **xtcjs / referência relacionada ao formato XTC/XTCH:** `https://github.com/varo6/xtcjs`

O código do CUMA mantém uma referência explícita a esse repositório em `XTCJS_REPO_URL`. As rotinas atuais do CUMA geram XTCH/XTH nativamente em Python, sem executar Node, npm, Bun ou workers externos, mas essa referência deve ser mantida nos créditos por estar relacionada à implementação/entendimento do formato.

### Bibliotecas Python usadas pelo aplicativo

- **Python / CPython:** `https://github.com/python/cpython`
- **PyMuPDF:** `https://github.com/pymupdf/PyMuPDF`
- **MuPDF, motor base usado pelo PyMuPDF:** `https://github.com/ArtifexSoftware/mupdf`
- **Pillow / PIL:** `https://github.com/python-pillow/Pillow`
- **NumPy:** `https://github.com/numpy/numpy`
- **tkinterdnd2, drag-and-drop opcional:** `https://github.com/pmgagne/tkinterdnd2`
- **PyInstaller, empacotamento do executável Windows:** `https://github.com/pyinstaller/pyinstaller`
- **OpenCV, usado apenas se disponível para detecção CUDA/OpenCL:** `https://github.com/opencv/opencv`

### Bibliotecas padrão do Python usadas no código

O CUMA também usa módulos da biblioteca padrão do Python, incluindo:

- `html`
- `json`
- `os`
- `queue`
- `re`
- `shutil`
- `subprocess`
- `sys`
- `threading`
- `traceback`
- `time`
- `collections`
- `concurrent.futures`
- `uuid`
- `hashlib`
- `struct`
- `zipfile`
- `colorsys`
- `dataclasses`
- `datetime`
- `io`
- `pathlib`
- `typing`
- `ctypes`
- `winreg`
- `urllib.request`
- `locale`
- `webbrowser`

Esses módulos fazem parte do Python/CPython e não precisam ser instalados separadamente.

### Interface gráfica

- **Tkinter:** biblioteca gráfica incluída com Python em builds comuns do Windows.
- **Tcl/Tk:** `https://www.tcl.tk/`
- **Tk/Ttk:** usado para widgets, abas, botões, comboboxes, treeviews, barras de rolagem e temas.

### Serviços externos usados pelo projeto

- **GitHub:** `https://github.com/`
- **GitHub Releases:** usado para hospedar `CUMA_windows.zip`.
- **GitHub raw content:** usado para servir `updates/stable.json`.
- **GitHub Actions:** usado pelo workflow `.github/workflows/atualizar_stable_json.yml`.
- **actions/checkout:** `https://github.com/actions/checkout`
- **GitHub CLI / gh:** `https://github.com/cli/cli`
- **Buy Me a Coffee:** `https://www.buymeacoffee.com/soldieg`
- **Buy Me a Coffee button API:** `https://img.buymeacoffee.com/button-api/`

### Especificações e formatos usados

- **PDF:** manipulado via PyMuPDF/MuPDF.
- **EPUB:** pacote ZIP com estrutura OPF/XHTML/imagens.
- **CBZ:** arquivo ZIP contendo imagens, usado por leitores de quadrinhos.
- **ZIP:** usado por EPUB, CBZ e pacotes de atualização.
- **XHTML:** `http://www.w3.org/1999/xhtml`
- **OPF / IDPF:** `http://www.idpf.org/2007/opf`
- **OPS / IDPF:** `http://www.idpf.org/2007/ops`
- **Dublin Core Metadata:** `http://purl.org/dc/elements/1.1/`
- **JPEG/JPG, PNG, WebP, BMP, TIFF:** formatos de imagem lidos/escritos via Pillow.
- **SHA-256:** usado para validar integridade do ZIP de atualização.
- **MD5:** usado internamente em páginas XTH/XTCH para digest curto de dados de página.

### Observação de créditos

Esta lista foi montada a partir das referências explícitas, imports, URLs, arquivos de build e formatos encontrados no projeto. Se alguma rotina tiver sido adaptada de fórum, gist, issue, conversa técnica ou repositório externo que não esteja registrado no código, o link original deve ser adicionado aqui antes do lançamento público.


### Ferramentas externas opcionais

- **7-Zip:** `https://www.7-zip.org/` — usado opcionalmente para abrir CBR/RAR/7Z no Windows.
