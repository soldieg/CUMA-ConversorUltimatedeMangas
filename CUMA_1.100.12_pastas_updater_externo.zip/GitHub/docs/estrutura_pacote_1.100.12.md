# Estrutura do pacote CUMA 1.100.12

Esta versão foi organizada para facilitar atualização do repositório e publicação da release.

## Pastas do pacote extraído

- `GitHub`: contém os arquivos do projeto para copiar/subir no repositório.
- `arquivos necessários`: contém os arquivos `.bat` de uso diário.
- `ZIP final`: recebe o `CUMA_windows.zip` depois da compilação.

## Atualizador

O botão `Procurar atualizações` do CUMA principal agora chama o `cuma_updater.exe`.
O CUMA principal não faz mais o download nem a instalação diretamente.

Fluxo:

1. CUMA abre `cuma_updater.exe --check`.
2. O atualizador lê `updates/stable.json` no GitHub.
3. Se houver nova versão, mostra:
   - `Atualizar agora`;
   - `Baixar manualmente`.
4. Em `Atualizar agora`, o atualizador baixa o ZIP, valida SHA256, inicia uma cópia temporária dele mesmo, fecha o CUMA e instala.
5. Em `Baixar manualmente`, apenas abre o link do GitHub no navegador.

## Publicação

1. Rode `arquivos necessários\criar_exe_windows_e_zip.bat`.
2. Envie `ZIP final\CUMA_windows.zip` para a Release `Stable`.
3. Suba o conteúdo de `GitHub` para o repositório.
