# Roadmap completo do CUMA

Este documento transforma a análise do KCC em um plano de versões para o CUMA.

Versão atual de trabalho: **1.081.3**  
Base oficial de versionamento: **1.080.0**

Importante: este arquivo é um **plano de implementação**. Ele não afirma que os recursos abaixo já existem no executável atual. A ideia é usar isso como guia de desenvolvimento, GitHub Issues, Milestones e Releases.

## Estratégia

O CUMA já está maduro para lançamento inicial. O próximo passo não deve ser misturar todos os recursos de uma vez. O caminho mais seguro é:

1. lançar/manter a base estável;
2. implementar uma versão pequena com melhorias de baixo risco;
3. implementar uma versão média com otimizações visuais;
4. implementar uma versão grande com preview, metadados e formatos avançados.

## Versões planejadas

| Versão | Tipo | Nome | Objetivo |
|---|---:|---|---|
| `1.082.0` | pequena | Perfis e leitura | Perfis reais de dispositivos, ordenação natural, modo mangá/ocidental e avisos melhores. |
| `1.090.0` | média | Otimização E-ink | Remover margens, dividir páginas duplas e aplicar presets de imagem para e-readers. |
| `1.100.0` | grande dentro da linha 1.x | Experiência avançada | Preview, metadados, CBZ/ZIP/CBR, webtoon e fila de conversão. |

## Como usar este roadmap no GitHub

Crie estes Milestones no GitHub:

- `1.082.0 - Perfis e leitura`
- `1.090.0 - Otimização E-ink`
- `1.100.0 - Experiência avançada`

Depois transforme cada item dos documentos individuais em Issues.

Documentos individuais:

- [`1.082.0_perfis_e_leitura.md`](./1.082.0_perfis_e_leitura.md)
- [`1.090.0_otimizacao_eink.md`](./1.090.0_otimizacao_eink.md)
- [`1.100.0_experiencia_avancada.md`](./1.100.0_experiencia_avancada.md)

## Referência KCC

O KCC foi analisado como referência técnica para otimização de quadrinhos/mangás em e-readers.

Referência:

- Kindle Comic Converter / KCC
- Repositório: `https://github.com/ciromattia/kcc`
- Licença: ISC License

Arquivos de referência incluídos neste pacote:

- `docs/referencias/kcc_device_profiles_para_cuma.json`
- `docs/referencias/KCC_LICENSE_ISC.txt`

Se algum código, tabela ou algoritmo do KCC for copiado/adaptado diretamente, mantenha atribuição e licença no README, manual e/ou arquivo de créditos.
