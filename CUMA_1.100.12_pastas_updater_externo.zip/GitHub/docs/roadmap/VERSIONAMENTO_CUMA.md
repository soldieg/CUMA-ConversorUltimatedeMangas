# Regras de versionamento do CUMA

Base oficial definida: **1.080.0**

## Tipos de atualização

| Tipo | Exemplo | Quando usar |
|---|---|---|
| Pouca/correção | `1.081.3` → `1.081.4` | Correção de bug, texto, README, manifesto, ajuste pequeno. |
| Pequena | `1.081.3` → `1.082.0` | Recurso compatível, baixo risco, sem alterar núcleo pesado. |
| Média | `1.082.0` → `1.090.0` | Grupo de recursos com impacto maior, mas ainda dentro da linha 1.x. |
| Grande | `1.100.0` → `2.000.0` | Mudança estrutural, interface muito diferente, novo motor ou quebra relevante. |

## Sequência recomendada agora

```text
1.081.3  atual
1.082.0  perfis e leitura
1.090.0  otimização E-ink
1.100.0  experiência avançada
```

## Tags no GitHub

Use sempre:

```text
v1.082.0
v1.090.0
v1.100.0
```

## Releases

Cada release deve conter:

```text
CUMA_windows.zip
```

O manifesto `updates/stable.json` deve sempre apontar para a última release estável.
