# Issues prontas para GitHub — Roadmap CUMA

Use este arquivo para criar Issues e Milestones no GitHub.

## Milestone: 1.082.0 - Perfis e leitura

### Issue: Adicionar perfis reais de dispositivos
Labels: `enhancement`, `converter`, `1.082.0`

Checklist:
- [ ] Criar lista Kindle/Kobo/reMarkable/XTEINK/Tablet/Smartphone.
- [ ] Salvar perfil escolhido em `cuma_settings.json`.
- [ ] Restaurar perfil ao abrir app.
- [ ] Atualizar manual.

### Issue: Implementar ordenação natural
Labels: `enhancement`, `files`, `1.082.0`

Checklist:
- [ ] Implementar função de ordenação natural sem dependência pesada.
- [ ] Aplicar em imagens→PDF.
- [ ] Aplicar em fluxos futuros de pasta/CBZ.
- [ ] Testar `1.jpg`, `2.jpg`, `10.jpg`.

### Issue: Adicionar ordem de leitura Ocidental/Mangá
Labels: `enhancement`, `manga`, `1.082.0`

Checklist:
- [ ] Adicionar opção visual.
- [ ] Salvar no settings.
- [ ] Documentar uso.
- [ ] Preparar uso para páginas duplas na 1.090.0.

### Issue: Melhorar avisos de erro
Labels: `ux`, `bugfix`, `1.082.0`

Checklist:
- [ ] PDF com senha.
- [ ] PDF corrompido.
- [ ] EPUB textual.
- [ ] Pasta sem permissão.
- [ ] Falha no manifesto de atualização.

## Milestone: 1.090.0 - Otimização E-ink

### Issue: Remoção automática de margens
Labels: `enhancement`, `image-processing`, `1.090.0`

Checklist:
- [ ] Modo desativado/suave/normal/forte.
- [ ] Margem preservada.
- [ ] Testes com bordas brancas.
- [ ] Testes com bordas pretas.
- [ ] Opção para desligar.

### Issue: Remoção de número de página
Labels: `enhancement`, `image-processing`, `1.090.0`

Checklist:
- [ ] Detectar rodapé de forma conservadora.
- [ ] Evitar corte de balões/texto.
- [ ] Adicionar opção avançada.

### Issue: Divisão de páginas duplas
Labels: `enhancement`, `manga`, `1.090.0`

Checklist:
- [ ] Detectar página horizontal.
- [ ] Dividir em duas páginas.
- [ ] Respeitar Ocidental/Mangá.
- [ ] Tratar capas horizontais.

### Issue: Presets de imagem para e-reader
Labels: `enhancement`, `e-ink`, `1.090.0`

Checklist:
- [ ] Original.
- [ ] Mangá P&B.
- [ ] Contraste alto.
- [ ] Cinza suave.
- [ ] Colorido preservado.
- [ ] Arquivo menor.
- [ ] Alta qualidade.

## Milestone: 1.100.0 - Experiência avançada

### Issue: Preview antes/depois
Labels: `enhancement`, `ui`, `1.100.0`

Checklist:
- [ ] Selecionar página de amostra.
- [ ] Mostrar original.
- [ ] Mostrar processada.
- [ ] Comparar presets.

### Issue: Editor de metadados
Labels: `enhancement`, `epub`, `1.100.0`

Checklist:
- [ ] Título.
- [ ] Autor.
- [ ] Série.
- [ ] Volume.
- [ ] Idioma.
- [ ] Capa.

### Issue: Suporte CBZ/ZIP e preparação para CBR/RAR/7Z
Labels: `enhancement`, `formats`, `1.100.0`

Checklist:
- [ ] CBZ nativo.
- [ ] ZIP com imagens.
- [ ] Ordenação natural.
- [ ] Mensagem clara para RAR/7Z sem ferramenta.

### Issue: Fila de conversão avançada
Labels: `enhancement`, `queue`, `1.100.0`

Checklist:
- [ ] Status por arquivo.
- [ ] Progresso.
- [ ] Abrir saída.
- [ ] Repetir erro.
- [ ] Cancelar quando possível.
