# Arquivos para o repositório GitHub do CUMA

## 1. Arquivos que DEVEM entrar no repositório

```text
cuma.py
cuma.spec
cuma_updater.py
requirements.txt
criar_exe_windows_e_zip.bat
rodar_cuma.bat
app_icon.ico
cuma_logo.png
manual_do_programa.txt
LEIA-ME.txt
ATUALIZACOES_DESDE_1.100.2.txt
README.md
LICENSE
.gitignore
cuma_settings_template.json
updates/stable.json
docs/manual_do_programa.txt
docs/historico_versoes.md
docs/arquivos_github.md
scripts/preparar_manifesto_release.py
```

## 2. Arquivos que NÃO devem entrar no repositório

```text
dist/
build/
_internal/
__pycache__/
*.pyc
*.pyo
*.log
erro.txt
CUMA.log
limpos/
CUMA_windows.zip
cuma.exe
cuma_settings.json
config_cuma.json
cuma_interface_colors.json
cuma_version_state.json
cuma_version_history.json
cuma_device_profiles.json
version.json
debug_*.json
validacao_*.json
RELATORIO_*.txt
*.rar
*.7z
```

## 3. Arquivo que vai em GitHub Releases, não no código-fonte

```text
CUMA_windows.zip
```

Esse arquivo é gerado no Windows pelo `criar_exe_windows_e_zip.bat`.

## 4. Arquivos que o usuário final verá depois de extrair o ZIP compilado

```text
CUMA/
  cuma.exe
  cuma_updater.exe
  manual_do_programa.txt
  LEIA-ME.txt
  ATUALIZACOES_DESDE_1.100.2.txt
  _internal/
```

## 5. Arquivos que ficam no computador do usuário depois que o app roda

```text
%APPDATA%\CUMA\
  cuma_settings.json
  CUMA.log
  erro.txt
```

Esses arquivos não devem ser apagados durante uma atualização.

## 6. Campos que você deve trocar antes de publicar

O repositório oficial está configurado como `soldieg/CUMA` em:

```text
README.md
updates/stable.json
cuma_settings_template.json
```

Depois de compilar e criar a Release, atualize em `updates/stable.json`:

```text
version
published_at
download_url
sha256
size_bytes
release_notes
```

- `gerar_info_release.bat`: calcula SHA256 e tamanho do `CUMA_windows.zip` e atualiza `updates/stable.json` após a compilação Windows.

- `NOTAS_RELEASE_1.100.11_GITHUB.txt`: notas do atualizador automático 1.100.11.


## CUMA 1.100.12

Use a pasta `GitHub` como raiz do repositório. Os BATs de uso ficam fora dela, em `arquivos necessários`, e o pacote final é gerado em `ZIP final`.
