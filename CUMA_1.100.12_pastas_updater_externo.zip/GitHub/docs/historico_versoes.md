## 1.100.11

- Adiciona atualizador automático via GitHub Releases.
- Inclui o botão **Atualizar agora** para baixar, validar SHA256, fechar o CUMA e instalar.
- Mantém o botão **Baixar manualmente** para instalação manual.
- Adiciona `cuma_updater.exe` externo para substituir os arquivos com segurança.
- Mantém backup da versão anterior durante a atualização.


## 1.100.10

- Corrige definitivamente o rodapé da janela de atualizações para os botões não ficarem escondidos.
- Mantém **Cancelar** sempre visível.
- Mostra **Baixar** quando há atualização disponível com link.
- Mantém a caixa de detalhes com rolagem vertical.


## 1.100.9

- Corrige a janela de atualização para manter os botões no rodapé fixo.
- Exibe **Baixar** quando há atualização disponível e **Cancelar** sempre.
- Mantém a caixa de detalhes com rolagem vertical.
- Ajusta build Windows para pasta `dist\CUMA_windows`.
- Adiciona `gerar_info_release.bat` para calcular SHA256 e tamanho do ZIP final.

# Histórico de versões do CUMA

## 1.100.7 — Manuais e histórico consolidados

- Manual da raiz e `docs/manual_do_programa.txt` atualizados para explicar as funções recentes.
- Manual TXT gerado pelo botão **Manual** do aplicativo alinhado com a versão atual.
- Criado `ATUALIZACOES_DESDE_1.100.2.txt` com resumo das versões 1.100.2 até 1.100.7.
- `README.md`, `LEIA-ME.txt` e `updates/stable.json` alinhados com a versão 1.100.7.

## 1.100.6 — Criar PDF de imagens aceita mais formatos

- Em **Ferramentas > Criar PDF de imagens**, agora também é possível adicionar PDFs.
- A ferramenta também aceita CBZ, ZIP e EPUB com imagens.
- CBR, RAR e 7Z são aceitos quando o 7-Zip está instalado e disponível no PATH.
- A geração respeita a ordem manual da lista.
- EPUB textual puro não é renderizado nessa função; EPUB com imagens é aceito.

## 1.100.5 — Ordem manual de arquivos e layout compacto

- Botões **Mover pra cima ↑** e **Mover pra baixo ↓** adicionados nas filas de Limpar, Ferramentas e Converter.
- Reordenação por clicar, segurar e arrastar uma linha da lista.
- A ordem visível da lista é respeitada nas rotinas associadas.
- Removido o grande espaço vazio entre os botões e a lista da aba Converter.

## 1.100.4

- Acabamento visual da aba Converter.
- Conversões compatíveis integradas ao painel **Dispositivos e conversões**.
- Botão **Metadados EPUB** exibido apenas quando o arquivo é EPUB ou quando alguma conversão para EPUB está marcada.
- Opções KCC/E-ink movidas para **Configurações do PDF**, mantendo a aba Limpar principal mais limpa.
- Botão antigo **Prévia** da aba Limpar substituído por **Prévia Limpar**.
- Corrigida a legibilidade do hover em tabelas/cabeçalhos.
- Mantida a separação: **Limpar prepara/modifica** e **Converter apenas converte**.

## 1.100.3 — Limpar com KCC real e Converter sem prévia duplicada

- As opções KCC/E-ink da aba Limpar agora entram no processamento real do PDF limpo.
- A opção **Dividir páginas duplas** divide páginas largas em páginas reais no PDF final.
- **Manter original ao dividir** preserva a página inteira e adiciona as metades.
- **Webtoon/imagens longas**, presets E-ink, corte de margens e rodapé pertencem à aba Limpar.
- A aba Converter segue em conversão pura e não reaplica alterações visuais.
- O botão de prévia do Converter foi unificado para evitar duas prévias na mesma aba.

## 1.100.2 — Converter em modo puro

- Corrige a separação entre Limpar e Converter.
- Converter deixa de reaplicar remoção de margens, presets E-ink, páginas duplas, webtoon e rodapé/número de página.
- PDF→EPUB, PDF→CBZ, PDF→imagens, EPUB→PDF, compactados→EPUB/PDF e imagem→PDF/EPUB preservam a entrada sem canvas branco de dispositivo.
- Prévia do Converter passa a mostrar a entrada real sem encaixe por perfil.
- Prévia antes/depois da preparação visual não usa mais o alvo do dispositivo.
- XTCH continua usando dimensões fixas do dispositivo por exigência do formato, mas sem reaplicar filtros da aba Limpar.

## 1.100.1 — Reorganização Limpar/Converter

- Move presets E-ink, leitura, corte, página dupla e webtoon para a aba Limpar.
- Mantém dispositivos, prévia e metadados no Converter.
- Adiciona conversões dinâmicas por tipo de arquivo selecionado.
- Novas rotas: PDF→CBZ, PDF→imagens, EPUB→PDF, compactados→PDF e imagem→PDF/EPUB/XTCH.


## 1.100.0 — Experiência avançada consolidada

- Consolidação de perfis e leitura, otimização E-ink e experiência avançada.
- Correção das conexões oficiais de atualização para `soldieg/CUMA`.


Consolida em uma única versão as etapas planejadas `1.082.0`, `1.090.0` e `1.100.0`.

### Vinha de 1.082.0 — Perfis e leitura

- Perfis reais de dispositivos Kindle, Kobo e reMarkable inspirados no KCC.
- Ordenação natural para arquivos e imagens.
- Ordem de leitura Ocidental/Mangá.
- Mensagens mais claras para formatos compactados que dependem de 7-Zip.

### Vinha de 1.090.0 — Otimização E-ink

- Remoção automática de margens.
- Remoção opcional de número de página/rodapé.
- Divisão de páginas duplas.
- Presets de imagem para E-reader/E-ink.
- Processamento XTCH com contagem real quando páginas são divididas.

### Vinha de 1.100.0 — Experiência avançada

- Prévia antes/depois.
- Editor simples de metadados para EPUB.
- CBZ/ZIP nativos.
- CBR/RAR/7Z por 7-Zip instalado.
- Modo webtoon/imagens longas.
- Painel avançado na aba Converter.

## 1.081.3

- Pop-up de atualização com visual do CUMA.
- Manifesto GitHub preparado.
- README e referências de código.

## 1.081.2

- Configurações consolidadas em `cuma_settings.json`.
- Dados do usuário movidos para `%APPDATA%\CUMA`.
- Pacote final mais limpo.

## 1.081.1

- Release estável.
- Manual expandido.
- Redução de arquivos de debug.

## 1.081.0

- Temas baseados no ícone.
- Ajustes visuais na interface.
- Melhorias na sidebar, abas e scrollbars.

## 1.080.0

- Nova base oficial de versionamento.


## 1.100.8 - Correções de auditoria

- Corrigido bug de CBZ/ZIP no Converter.
- Corrigido CBR/RAR/7Z no Converter quando 7-Zip está instalado.
- Escrita atômica/temporária para EPUB, CBZ e PDFs gerados.
- Ferramentas validam arquivos existentes antes de processar.
- O ZIP de release não deve incluir `.cuma_user_data`.
- Script de build copia documentação e prepara manifesto com SHA256/tamanho.
- `requirements.txt` passou a usar faixas de versão.
