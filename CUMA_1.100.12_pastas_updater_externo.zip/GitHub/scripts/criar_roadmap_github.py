#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Cria milestones e issues do roadmap no GitHub usando GitHub CLI.

Pré-requisitos:
  gh auth login
  executar na raiz do repositório CUMA

Uso:
  python scripts/criar_roadmap_github.py
"""

import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ROADMAP = ROOT / "docs" / "roadmap" / "roadmap.json"

def run(cmd):
    print("+", " ".join(cmd))
    subprocess.run(cmd, check=True)

def main():
    data = json.loads(ROADMAP.read_text(encoding="utf-8"))
    for version in data["versions"]:
        milestone_title = f'{version["version"]} - {version["codename"]}'
        description = version["goal"]
        # gh não tem comando idempotente simples para milestone em todas as versões.
        # Se já existir, este comando pode falhar; nesse caso ignore e siga criando Issues manualmente.
        try:
            run(["gh", "api", "repos/:owner/:repo/milestones", "-f", f"title={milestone_title}", "-f", f"description={description}"])
        except subprocess.CalledProcessError:
            print(f"Milestone possivelmente já existe: {milestone_title}")

        for item in version["items"]:
            body = (
                f"Versão alvo: `{version['version']}`\n\n"
                f"Milestone: `{milestone_title}`\n\n"
                f"## Descrição\n\n{item}\n\n"
                "## Critérios de aceite\n\n"
                + "\n".join(f"- [ ] {c}" for c in version["acceptance_criteria"][:5])
            )
            try:
                run([
                    "gh", "issue", "create",
                    "--title", f"[{version['version']}] {item[:80]}",
                    "--body", body,
                    "--label", "enhancement"
                ])
            except subprocess.CalledProcessError:
                print(f"Falha ao criar issue: {item}")

if __name__ == "__main__":
    main()
