#!/usr/bin/env python3
r"""
Prepara o manifesto de atualização do CUMA para GitHub Releases.

Uso recomendado para o repositório oficial:
  python scripts/preparar_manifesto_release.py soldieg CUMA 1.100.0 C:\caminho\para\CUMA_windows.zip Stable

Uso com notas:
  python scripts/preparar_manifesto_release.py soldieg CUMA 1.100.0 C:\caminho\para\CUMA_windows.zip Stable RELEASE_NOTES.md

Argumentos:
  1. dono do repositório, exemplo: soldieg
  2. nome do repositório, exemplo: CUMA
  3. versão numérica do app, exemplo: 1.100.0
  4. caminho opcional para CUMA_windows.zip
  5. tag opcional da Release, padrão: Stable
  6. arquivo opcional de notas

O script atualiza:
- README.md
- updates/stable.json
- cuma_settings_template.json

Ele calcula SHA256 e tamanho do ZIP automaticamente quando o caminho do ZIP é informado.
"""
from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path
from datetime import date

ROOT = Path(__file__).resolve().parents[1]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest().upper()


def release_notes_from_file(path: Path | None) -> list[str]:
    if not path or not path.exists():
        return ["Atualização do CUMA publicada via GitHub Releases."]
    raw = path.read_text(encoding="utf-8", errors="replace").strip()
    if not raw:
        return ["Atualização do CUMA publicada via GitHub Releases."]

    notes: list[str] = []
    for line in raw.splitlines():
        item = line.strip()
        if not item:
            continue
        item = re.sub(r"^#{1,6}\s*", "", item).strip()
        item = re.sub(r"^[-*•]\s*", "", item).strip()
        if item:
            notes.append(item)
        if len(notes) >= 12:
            break
    return notes or ["Atualização do CUMA publicada via GitHub Releases."]


def main() -> int:
    if len(sys.argv) < 4:
        print("Uso: python scripts/preparar_manifesto_release.py soldieg CUMA 1.100.0 [CUMA_windows.zip] [Stable] [RELEASE_NOTES.md]")
        return 2

    owner = sys.argv[1].strip()
    repo = sys.argv[2].strip()
    version = sys.argv[3].strip().lstrip("v")

    zip_path = None
    release_tag = "Stable"
    notes_path = None

    if len(sys.argv) >= 5 and sys.argv[4].strip():
        candidate = Path(sys.argv[4]).expanduser()
        # Se o 4º argumento parece um ZIP/caminho existente, ele é o ZIP.
        if str(candidate).lower().endswith(".zip") or candidate.exists():
            zip_path = candidate.resolve()
        else:
            release_tag = sys.argv[4].strip()

    if len(sys.argv) >= 6 and sys.argv[5].strip():
        # Quando há ZIP no argumento 4, o argumento 5 é tag. Caso contrário, é notas.
        if zip_path is not None:
            release_tag = sys.argv[5].strip()
        else:
            notes_path = Path(sys.argv[5]).resolve()

    if len(sys.argv) >= 7 and sys.argv[6].strip():
        notes_path = Path(sys.argv[6]).resolve()

    raw_url = f"https://raw.githubusercontent.com/{owner}/{repo}/main/updates/stable.json"
    download_url = f"https://github.com/{owner}/{repo}/releases/download/{release_tag}/CUMA_windows.zip"

    readme_path = ROOT / "README.md"
    if readme_path.exists():
        txt = readme_path.read_text(encoding="utf-8")
        txt = txt.replace("https://github.com/soldiego/CUMA", f"https://github.com/{owner}/{repo}")
        txt = txt.replace("https://raw.githubusercontent.com/soldiego/CUMA/main/updates/stable.json", raw_url)
        txt = txt.replace("https://github.com/soldieg/CUMA", f"https://github.com/{owner}/{repo}")
        txt = txt.replace("https://raw.githubusercontent.com/soldieg/CUMA/main/updates/stable.json", raw_url)
        txt = txt.replace("https://github.com/SEU_USUARIO/CUMA", f"https://github.com/{owner}/{repo}")
        txt = txt.replace("SEU_USUARIO/CUMA", f"{owner}/{repo}")
        txt = txt.replace("SEU_USUARIO", owner)
        readme_path.write_text(txt, encoding="utf-8")

    template_path = ROOT / "cuma_settings_template.json"
    if template_path.exists():
        data = json.loads(template_path.read_text(encoding="utf-8"))
        cfg = data.setdefault("config", {})
        cfg["update_manifest_url"] = raw_url
        cfg["update_channel"] = "stable"
        updates = data.setdefault("updates", {})
        updates["manifest_url"] = raw_url
        updates["channel"] = "stable"
        updates["release_tag"] = release_tag
        updates["download_url"] = download_url
        data.setdefault("versioning", {})["current_version"] = version
        template_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    stable_path = ROOT / "updates" / "stable.json"
    stable_path.parent.mkdir(parents=True, exist_ok=True)
    if stable_path.exists():
        stable = json.loads(stable_path.read_text(encoding="utf-8"))
    else:
        stable = {}

    stable.update({
        "app_id": "cuma",
        "channel": "stable",
        "version": version,
        "minimum_supported_version": stable.get("minimum_supported_version", "1.080.0"),
        "mandatory": bool(stable.get("mandatory", False)),
        "published_at": date.today().isoformat(),
        "download_url": download_url,
        "release_notes": release_notes_from_file(notes_path),
    })

    if zip_path and zip_path.exists():
        stable["sha256"] = sha256_file(zip_path)
        stable["size_bytes"] = zip_path.stat().st_size
    else:
        stable["sha256"] = "COLOQUE_O_SHA256_DO_ZIP_AQUI"
        stable["size_bytes"] = 0

    stable_path.write_text(json.dumps(stable, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print("Arquivos atualizados:")
    print(f"- {readme_path}")
    print(f"- {template_path}")
    print(f"- {stable_path}")
    print()
    print("URL raw do manifesto:")
    print(raw_url)
    print()
    print("URL da release:")
    print(download_url)
    print()
    print(f"SHA256: {stable['sha256']}")
    print(f"Tamanho: {stable['size_bytes']} bytes")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
