---
name: Bug report
about: Reportar erro no CUMA
title: "[Bug] "
labels: bug
assignees: ''
---

## Versão do CUMA

Exemplo: `1.081.3`

## Descrição do problema

Explique o que aconteceu.

## Passos para reproduzir

1.
2.
3.

## Resultado esperado

O que deveria acontecer?

## Arquivo usado

Tipo de arquivo: PDF / EPUB / XTCH / imagens / outro

## Logs ou mensagem de erro

Cole aqui se houver.
