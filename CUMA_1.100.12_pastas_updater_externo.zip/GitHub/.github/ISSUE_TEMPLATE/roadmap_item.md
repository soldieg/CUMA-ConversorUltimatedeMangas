---
name: Roadmap item
about: Item planejado do roadmap do CUMA
title: "[Roadmap] "
labels: enhancement
assignees: ''
---

## Versão alvo

Exemplo: `1.082.0`

## Descrição

Descreva o recurso ou ajuste.

## Critérios de aceite

- [ ] Critério 1
- [ ] Critério 2
- [ ] Manual atualizado
- [ ] Teste básico executado

## Riscos

Liste riscos de compatibilidade, performance ou UX.
