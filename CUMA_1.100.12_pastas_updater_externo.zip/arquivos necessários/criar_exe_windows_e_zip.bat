@echo off
setlocal EnableExtensions
chcp 65001 >nul
title CUMA - Compilar Windows e gerar ZIP
set "TOOLS_DIR=%~dp0"
set "SRC_DIR=%~dp0..\GitHub"
set "ZIP_DIR=%~dp0..\ZIP final"
set "APP_VERSION=1.100.12"
set "OUT_DIR=dist\CUMA_windows"
set "ZIP_NAME=CUMA_windows.zip"
set "ZIP_PATH=%ZIP_DIR%\%ZIP_NAME%"
set "RELEASE_NOTES=NOTAS_RELEASE_1.100.12_GITHUB.txt"

if not exist "%SRC_DIR%\cuma.py" (
  echo [ERRO] cuma.py nao encontrado em:
  echo %SRC_DIR%
  echo.
  echo Confira se a estrutura extraida possui as pastas:
  echo GitHub
  echo arquivos necessarios
  echo ZIP final
  pause
  exit /b 1
)

if not exist "%ZIP_DIR%" mkdir "%ZIP_DIR%"
cd /d "%SRC_DIR%"

where python >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Python nao encontrado. Instale Python 3.11+ e marque "Add Python to PATH".
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Criando ambiente virtual .venv...
  python -m venv .venv
  if errorlevel 1 (
    echo [ERRO] Falha ao criar ambiente virtual.
    pause
    exit /b 1
  )
)

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo [ERRO] Falha ao instalar dependencias.
  pause
  exit /b 1
)

if exist build rd /s /q build
if exist dist rd /s /q dist

echo.
echo Gerando executaveis com PyInstaller...
python -m PyInstaller --noconfirm cuma.spec
if errorlevel 1 (
  echo [ERRO] Falha ao criar executaveis.
  pause
  exit /b 1
)

if not exist "%OUT_DIR%" (
  echo [ERRO] Pasta final "%OUT_DIR%" nao foi criada.
  pause
  exit /b 1
)

if not exist "%OUT_DIR%\cuma.exe" (
  echo [ERRO] cuma.exe nao foi criado.
  pause
  exit /b 1
)

if not exist "%OUT_DIR%\cuma_updater.exe" (
  echo [ERRO] cuma_updater.exe nao foi criado.
  echo O botao de atualizacao depende desse aplicativo externo.
  pause
  exit /b 1
)

echo.
echo Organizando pasta final: %OUT_DIR%
if not exist "%OUT_DIR%\_internal" mkdir "%OUT_DIR%\_internal"

if exist "manual_do_programa.txt" copy /Y "manual_do_programa.txt" "%OUT_DIR%\manual_do_programa.txt" >nul
if exist "LEIA-ME.txt" copy /Y "LEIA-ME.txt" "%OUT_DIR%\LEIA-ME.txt" >nul
for %%F in (README.md LICENSE ATUALIZACOES_DESDE_1.100.2.txt NOTAS_RELEASE_1.100.12_GITHUB.txt AUDITORIA_CORRECOES_1.100.8.txt) do (
  if exist "%%F" copy /Y "%%F" "%OUT_DIR%\%%F" >nul
)

for %%F in (cuma_settings_template.json cuma_logo.png app_icon.ico) do (
  if exist "%OUT_DIR%\%%F" move /Y "%OUT_DIR%\%%F" "%OUT_DIR%\_internal\%%F" >nul
)

for %%F in (
  config_cuma.json
  cuma_interface_colors.json
  cuma_device_profiles.json
  version.json
  cuma_version_state.json
  cuma_version_history.json
  CUMA.log
  CUMA_update.log
  erro.txt
  debug_completo_cuma.txt
  debug_patch_mesclado.json
  debug_patch_final_devices_languages.json
  RELATORIO_RELEASE_1_081_1.txt
) do (
  if exist "%OUT_DIR%\%%F" del /f /q "%OUT_DIR%\%%F" >nul 2>nul
  if exist "%OUT_DIR%\_internal\%%F" del /f /q "%OUT_DIR%\_internal\%%F" >nul 2>nul
)

if exist ".cuma_user_data" rd /s /q ".cuma_user_data"
if exist "%OUT_DIR%\.cuma_user_data" rd /s /q "%OUT_DIR%\.cuma_user_data"
if exist "%OUT_DIR%\limpos" rd /s /q "%OUT_DIR%\limpos"

echo.
echo Compactando release em:
echo %ZIP_PATH%
if exist "%ZIP_PATH%" del /f /q "%ZIP_PATH%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path '%OUT_DIR%\*' -DestinationPath '%ZIP_PATH%' -Force"
if errorlevel 1 (
  echo [ERRO] Falha ao criar %ZIP_PATH%.
  pause
  exit /b 1
)

echo.
echo Gerando informacoes da release, SHA256, tamanho e stable.json...
if exist "%TOOLS_DIR%gerar_info_release.bat" (
  call "%TOOLS_DIR%gerar_info_release.bat" "%ZIP_PATH%" "%APP_VERSION%" "%RELEASE_NOTES%" "%SRC_DIR%"
) else (
  echo [AVISO] gerar_info_release.bat nao encontrado em "%TOOLS_DIR%".
)

echo.
echo OK.
echo Executavel: %SRC_DIR%\%OUT_DIR%\cuma.exe
echo ZIP final: %ZIP_PATH%
echo Manifesto atualizado: %SRC_DIR%\updates\stable.json
echo.
echo Agora suba no GitHub:
echo 1^) A pasta GitHub para o repositorio
echo 2^) O arquivo ZIP final\CUMA_windows.zip para a Release Stable
echo.
pause
endlocal
