@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul

set "ZIP_FILE=%~1"
set "APP_VERSION=%~2"
set "NOTES_FILE=%~3"
set "SRC_DIR=%~4"

if "%SRC_DIR%"=="" set "SRC_DIR=%~dp0..\GitHub"
if "%ZIP_FILE%"=="" set "ZIP_FILE=%~dp0..\ZIP final\CUMA_windows.zip"
if "%APP_VERSION%"=="" set "APP_VERSION=1.100.12"
if "%NOTES_FILE%"=="" set "NOTES_FILE=NOTAS_RELEASE_1.100.12_GITHUB.txt"

if not exist "%SRC_DIR%\cuma.py" (
  echo [ERRO] Pasta GitHub invalida:
  echo %SRC_DIR%
  exit /b 1
)

cd /d "%SRC_DIR%"

if not exist "%ZIP_FILE%" (
  echo [ERRO] ZIP nao encontrado:
  echo %ZIP_FILE%
  exit /b 1
)

for %%A in ("%ZIP_FILE%") do set "ZIP_SIZE=%%~zA"

for /f "usebackq delims=" %%H in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "(Get-FileHash -Path '%ZIP_FILE%' -Algorithm SHA256).Hash.ToUpper()"`) do (
  set "ZIP_SHA256=%%H"
)

if "%ZIP_SHA256%"=="" (
  echo [ERRO] Nao foi possivel calcular SHA256.
  exit /b 1
)

echo.
echo ================= INFORMACOES DA RELEASE =================
echo Versao:   %APP_VERSION%
echo Arquivo:  %ZIP_FILE%
echo Tamanho:  %ZIP_SIZE% bytes
echo SHA256:   %ZIP_SHA256%
echo ==========================================================
echo.

(
  echo CUMA %APP_VERSION% - informacoes para GitHub
  echo.
  echo Arquivo: %ZIP_FILE%
  echo Tamanho: %ZIP_SIZE% bytes
  echo SHA256: %ZIP_SHA256%
  echo Download URL: https://github.com/soldieg/CUMA/releases/download/Stable/CUMA_windows.zip
  echo.
  echo O stable.json da pasta GitHub foi atualizado automaticamente se o script Python terminou sem erro.
) > "%~dp0INFORMACOES_RELEASE_WINDOWS.txt"

if exist "scripts\preparar_manifesto_release.py" (
  python scripts\preparar_manifesto_release.py soldieg CUMA %APP_VERSION% "%ZIP_FILE%" Stable "%NOTES_FILE%"
  if errorlevel 1 (
    echo [AVISO] O ZIP foi medido, mas o manifesto stable.json nao foi atualizado pelo script.
  ) else (
    echo Manifesto atualizado: %SRC_DIR%\updates\stable.json
  )
) else (
  echo [AVISO] scripts\preparar_manifesto_release.py nao encontrado.
)

echo Arquivo gerado: %~dp0INFORMACOES_RELEASE_WINDOWS.txt
endlocal
